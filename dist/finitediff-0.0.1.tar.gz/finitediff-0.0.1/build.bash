python -m build
python -m twine upload --repository testpypi dist/*
expect "Enter your username:"
send "__token__\r"
