import FD
import numpy as np

import FD
import numpy as np

# model parameters:
dx = 0.3
dt = 0.01
k = 1

# Create a single Model object for the domain, with a time dimension and space dimension(s).

m = FD.Model(
    {"x": np.arange(1,10,dx), 
     "t": np.arange(1,100,dt)},
    time_axis = "t")


# Create fields representing a property that changes over time as a scalar field. 
# For this example, temperature would be at the cells, while temperature flux would be at the edges between the cells.

T = FD.Field(m, "Temperature", n_time_ders = 1)
Tflux = FD.Field(m, "Temperature Flux", n_time_ders = 0, edge_axes = "x")


# Create stencils for numerical approximations of spatial derivatives.

cell_to_edge = FD.Stencil([-1/2,1/2],der_order=1,axis_type="cell",der_axis_type="edge")
edge_to_cell = FD.Stencil([-1/2,1/2],der_order=1,axis_type="edge",der_axis_type="cell")

# Boundary conditions and initial conditions are applied. 
# In this case, the temperature is fixed on one end and the flux is fixed on the other.

T.set_IC("0")
T.set_BC("sin(t)","x","start")
T.set_BC("0","x","end")

# Optionally, check stability. Note that this simple criteria is only valid for this specific example.
CFL = k*dt/dx**2
print(f"CFL: {round(CFL,3)}, must be under 0.5 for stability\n")


m.check_IC() # not required, but recommended: checks if all necessary initial conditions have been set up

# Run the simulation in a loop, updating the fields each iteration

while not m.finished:

    # Tflux = k*dT/dx:
    dTdx = cell_to_edge.der(T.prev,"x") 
    Tflux.assign_update(k * dTdx)

    # dT/dt = dTflux/dx:
    Tp = edge_to_cell.der(Tflux.new,"x")
    T.dot.assign_update(Tp)

    # T = int(dT/dt) dt:
    T.time_integrate_update()

    # increment time:
    m.increment_time()

# get numpy arrays of the temperature and temperature flux:
Tflux.data
T.data   

# create an interactive visual in the jupyter notebook:
m.interact() 

