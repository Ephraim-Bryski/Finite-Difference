from FD import *
import numpy as np

g = 9.8

m = Model(
    {"x":np.linspace(0,10,100),
     "y":np.linspace(0,10,100),
     "t":np.arange(0,4,0.01)},
     periodic=[],
     time_axis="t"
)


u = Field(m,"u",edge_axes="x",n_time_ders=1)
v = Field(m,"v",edge_axes="y",n_time_ders=1)
eta = Field(m,"eta",n_time_ders=1)

# creating two fields is an ugly solution since I haven't built in mapping a field between cells and edges yet
h_for_u = ConstantField(m,"bath",edge_axes="x")
h_for_v = ConstantField(m,"bath2",edge_axes="y")
bath = "(25-x-y)/20"
h_for_u.set(bath)
h_for_v.set(bath)

u.set_BC("sin(t*10)","x","start")
u.set_BC("0","x","end")

v.set_BC("0","y","start")
v.set_BC("0","y","end")

eta.set_IC("0")
u.set_IC("0")
v.set_IC("0")

c_e = Stencil([-1/2,1/2],1,axis_type="cell",der_axis_type="edge")
e_c = Stencil([-1/2,1/2],1,axis_type="edge",der_axis_type="cell")

m.check_IC()

while not m.finished:
    detadx = c_e.der(eta.prev,"x") # required to write u.prev

    detady = c_e.der(eta.prev,"y")

    u.dot.assign_update(g*detadx)

    v.dot.assign_update(g*detady)

    u.time_integrate_update()
    v.time_integrate_update()

    dhudx = e_c.der(h_for_u.always * u.new,"x")
    dhvdy = e_c.der(h_for_v.always * v.new,"y")

    eta.dot.assign_update(dhudx + dhvdy)

    eta.time_integrate_update()

    m.increment_time()
pass


